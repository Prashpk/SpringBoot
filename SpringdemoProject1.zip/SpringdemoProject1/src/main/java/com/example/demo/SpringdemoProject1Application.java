package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringdemoProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringdemoProject1Application.class, args);
	}

}
