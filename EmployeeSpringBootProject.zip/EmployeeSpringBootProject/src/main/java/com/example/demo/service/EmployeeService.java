package com.example.demo.service;

import java.util.List;


import com.example.demo.entity.Employee;
import com.example.demo.error.EmployeeNotFoundException;

public interface EmployeeService {

 public	Employee saveEmployee(Employee employee);

public List<Employee> fetchEmployeeList();

public void deleteEmployeeById(Long eid) throws EmployeeNotFoundException;//implement in EmployeeServiceImpl.java

public Employee fetchEmployeeById(Long eid) throws EmployeeNotFoundException;

public Employee updateEmployee(Long eid, Employee employee) throws EmployeeNotFoundException;


public Employee fetchEmployeeByName(String EmployeeName);

}
