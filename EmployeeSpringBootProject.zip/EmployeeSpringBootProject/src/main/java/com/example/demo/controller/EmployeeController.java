package com.example.demo.controller;

import java.util.List;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employee;
import com.example.demo.error.EmployeeNotFoundException;
import com.example.demo.service.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	EmployeeService employeeService;
	
	//save
@PostMapping("/employee/")
	public Employee saveEmployee(@Valid @RequestBody Employee employee) {
		return employeeService.saveEmployee(employee);
	}
//getallRecords
@GetMapping("/employee/")
   public List<Employee> fetctEmployeeList(){
	   return employeeService.fetchEmployeeList();
   }

//deleteRecord by id
@DeleteMapping("/employee/{id}")
 public String deleteEmployeeById(@PathVariable("id") Long did) throws EmployeeNotFoundException {
	
	employeeService.deleteEmployeeById(did);//ask to create method automatically
	return "Employee is deleted";
 }

  //get Employee By Id

  @GetMapping("/employee/{id}")
  public Employee fetchEmployeeById(@PathVariable("id") Long did) throws EmployeeNotFoundException {
	  return employeeService.fetchEmployeeById(did);
  }
  
  //update record
  
  @PutMapping("/employee/{id}")
  
  public Employee updateEmployee(@PathVariable ("id") Long did, @RequestBody Employee employee) throws EmployeeNotFoundException {
	  
	 
	return employeeService.updateEmployee(did,employee);
  }
  
}