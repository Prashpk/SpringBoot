package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

@Entity

public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
private Long employeeId;
	@NotBlank(message="please add employee name")
private String employeeName;
private Integer employeeAge;
private Double employeeSalary;
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
public Employee(Long employeeId, @NotBlank(message = "please add employee name") String employeeName,
		Integer employeeAge, Double employeeSalary) {
	super();
	this.employeeId = employeeId;
	this.employeeName = employeeName;
	this.employeeAge = employeeAge;
	this.employeeSalary = employeeSalary;
}
public Long getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(Long employeeId) {
	this.employeeId = employeeId;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public Integer getEmployeeAge() {
	return employeeAge;
}
public void setEmployeeAge(Integer employeeAge) {
	this.employeeAge = employeeAge;
}
public Double getEmployeeSalary() {
	return employeeSalary;
}
public void setEmployeeSalary(Double employeeSalary) {
	this.employeeSalary = employeeSalary;
}
@Override
public String toString() {
	return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeAge=" + employeeAge
			+ ", employeeSalary=" + employeeSalary + "]";
}




}
