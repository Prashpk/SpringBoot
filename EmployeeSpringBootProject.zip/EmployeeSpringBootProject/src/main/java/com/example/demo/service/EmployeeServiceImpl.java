package com.example.demo.service;

import java.util.List;

import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.entity.Employee;
import com.example.demo.error.EmployeeNotFoundException;
import com.example.demo.repository.EmployeeRepository;


@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepository repository;

	@Override
	public Employee saveEmployee(Employee employee) {
		return repository.save(employee);
		
	}

	@Override
	public List<Employee> fetchEmployeeList() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public void deleteEmployeeById(Long did) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		Optional<Employee> employee =repository.findById(did);
		if(!employee.isPresent()) {
			throw new EmployeeNotFoundException("Employee Not Available");
		}else {
			repository.deleteById(did);
		}
	}

	@Override
	public Employee fetchEmployeeById(Long eid) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		//System.out.println(did);
		
		Optional<Employee> employee =repository.findById(eid);
		if(!employee.isPresent()) {
			throw new EmployeeNotFoundException("EmployeeNot Available");
		}
		return repository.findById(eid).get();
	}

	@Override
	public Employee updateEmployee(Long eid, Employee employee) throws EmployeeNotFoundException {
		Optional<Employee> employee1=repository.findById(eid);
		Employee empDB=null;
		if(employee1.isPresent()) {
		 empDB=repository.findById(eid).get();
		if(Objects.nonNull(employee.getEmployeeName()) && !"".equalsIgnoreCase(employee.getEmployeeName())) {
			empDB.setEmployeeName(employee.getEmployeeName());
			
		}
		if(Objects.nonNull(employee.getEmployeeAge()) && !"".equals(employee.getEmployeeAge())) {
			empDB.setEmployeeAge(employee.getEmployeeAge());
			System.out.println(employee.getEmployeeAge());
		}
		if(Objects.nonNull(employee.getEmployeeSalary()) && !"".equals(employee.getEmployeeSalary())) {
			empDB.setEmployeeSalary(employee.getEmployeeSalary());
			System.out.println(employee.getEmployeeSalary());
		}
		
		return repository.save(empDB);
		}
		else {
			throw new EmployeeNotFoundException("Employee Not available");
		}
		}		

	@Override
	public Employee fetchEmployeeByName(String employeeName) {
		// TODO Auto-generated method stub
		return repository.findByEmployeeName(employeeName);
	}

	
}
	
	

